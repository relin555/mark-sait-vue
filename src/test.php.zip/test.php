<?php

var_dump("true");die;